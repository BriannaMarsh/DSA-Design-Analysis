// DSA Project 2.cpp : This file contains the 'main' function. Program execution begins and ends there.
//Author Name: Brianna Marsh

#include <iostream>
#include <string>
#include <algorithm>
#include <fstream>
#include <vector> 


using namespace std;




string courseCode;   //this section is defining my variables
string courseName;
string prerequisites;
string totalPrerequisites;
string p;
int code;
int i;
          


int main()
{
    ifstream projectFile;  //object that I have created
    projectFile.open("input.txt");  //opening my text file that I named projectFile

    if (projectFile.fail()) {  // the file does not open, the system will prompt you to try opening it again
        cout << "File not working. Please Try again";
    }
    else {   // when the file opens, it will start to parce and print the lines, line by line.
        string s;
        while (getline(projectFile, s)) {
            cout << s << endl;
            }
        projectFile.close(); //closing the file, once printed
    }

    sort(courseCode, courseName); //Selection sorting the file in aphanumeric order.
    {
        code[i];
            for(i = 0; i < courseCode; ++i) {
                cout << courseName << "in alphabetical order" << endl;
            }
    }

}


